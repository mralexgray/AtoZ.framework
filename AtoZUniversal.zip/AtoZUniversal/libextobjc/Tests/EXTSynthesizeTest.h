//
//  EXTSynthesizeTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 2012-09-04.
//  Copyright (C) 2012 Justin Spahr-Summers.
//  Released under the MIT license.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXTSynthesizeTest : SenTestCase

@end
