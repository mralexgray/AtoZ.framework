//
//  EXTSelectorCheckingTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 26.06.12.
//  Copyright (C) 2012 Justin Spahr-Summers.
//  Released under the MIT license.
//

#import <SenTestingKit/SenTestingKit.h>
#import "EXTSelectorChecking.h"

@interface EXTSelectorCheckingTest : SenTestCase

@end
