//
//  EXTKeypathWeakWarningTest.h
//  extobjc
//
//  Created by Javier Soto on 6/23/14.
//
//

#import <SenTestingKit/SenTestingKit.h>
#import "EXTKeyPathCoding.h"

@interface EXTKeypathWeakWarningTest : SenTestCase

@end