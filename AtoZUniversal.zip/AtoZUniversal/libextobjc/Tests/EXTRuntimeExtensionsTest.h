//
//  EXTRuntimeExtensionsTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 2011-03-06.
//  Copyright (C) 2012 Justin Spahr-Summers.
//  Released under the MIT license.
//

#import <SenTestingKit/SenTestingKit.h>
#import <Foundation/Foundation.h>
#import "EXTRuntimeExtensions.h"

@interface EXTRuntimeExtensionsTest : SenTestCase {
    
}

@end
