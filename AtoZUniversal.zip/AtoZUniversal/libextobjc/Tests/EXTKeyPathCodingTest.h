//
//  EXTKeyPathCodingTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 19.06.12.
//
//

#import <SenTestingKit/SenTestingKit.h>
#import "EXTKeyPathCoding.h"

@interface EXTKeyPathCodingTest : SenTestCase

@end
