//
//  EXTObjectiveCppCompileTest.h
//  extobjc
//
//  Created by Igor Kashkuta on 2013-04-01.
//  Released under the MIT license.
//

#import <SenTestingKit/SenTestingKit.h>
#import "extobjc.h"

@interface EXTObjectiveCppCompileTest : SenTestCase

@end
