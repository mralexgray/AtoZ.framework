//
//  EXTADTTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 19.06.12.
//
//

#import <SenTestingKit/SenTestingKit.h>
#import "EXTADT.h"

@interface EXTADTTest : SenTestCase

@end
