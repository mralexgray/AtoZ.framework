//
//  EXTSafeCategoryTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 2010-11-13.
//  Copyright (C) 2012 Justin Spahr-Summers.
//  Released under the MIT license.
//

#import <SenTestingKit/SenTestingKit.h>
#import <Foundation/Foundation.h>

@interface EXTSafeCategoryTest : SenTestCase {

}

- (void)testSafeCategory;

@end
