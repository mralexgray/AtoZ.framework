//
//  EXTCoroutineTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 2011-05-22.
//  Copyright (C) 2012 Justin Spahr-Summers.
//  Released under the MIT license.
//

#import <SenTestingKit/SenTestingKit.h>
#import "EXTCoroutine.h"

@interface EXTCoroutineTest : SenTestCase {
@private
    
}

@end
