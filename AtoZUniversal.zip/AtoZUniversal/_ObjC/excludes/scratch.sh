NSAffineTransform
NSArray
NSAssertionHandler
NSAsyncSSDownloadManager
NSAtomicStoreCacheNode
NSAttributedString
NSAutoreleasePool
NSBag
NSBinaryObjectStoreFile
NSBlock
NSBundle
NSCFType
NSCache
NSCachedURLResponse
NSCachedURLResponseInternal
NSCalendar
NSCharacterSet
NSCoder
NSConcreteFileHandleARCWeakRef
NSCondition
NSConditionLock
NSConnection
NSConnectionHelper
NSCursor
NSData
NSDate
NSDateComponents
NSDecimalNumberHandler
NSDictionary
NSDistantObjectRequest
NSDistantObjectTableEntry
NSDocInfo
NSDocumentDifferenceSize
NSDocumentDifferenceSizeTriple
NSEncodingDetector
NSEntityDescription
NSEntityMapping
NSEntityMigrationPolicy
NSEnumerator
NSError
NSException
NSExpression
NSExtension
NSExtensionContext
NSExtensionItem
NSExternalRefCountedData
NSExtraLMData
NSFaultHandler
NSFetchedResultsController
NSFileAccessArbiter
NSFileAccessArbiterProxy
NSFileAccessClaim
NSFileAccessIntent
NSFileAccessNode
NSFileCoordinator
NSFileCoordinatorAccessorBlockCompletion
NSFileHandle
NSFileManager
NSFilePresenterOperationRecord
NSFilePresenterRelinquishment
NSFilePromiseWriteToken
NSFileProviderExtension
NSFileReactorProxy
NSFileSecurity
NSFileVersion
NSFileWatcher
NSFileWatcherObservations
NSFileWrapper
NSFileWrapperMoreIVars
NSFormatter
NSGZipDecoder
NSGlyphGenerator
NSGlyphInfo
NSHTMLReader
NSHTMLWebDelegate
NSHTMLWriter
NSHTTPCookie
NSHTTPCookieStorage
NSHTTPCookieStorageInternal
NSHTTPURLRequestParameters
NSHTTPURLResponseInternal
NSHashTable
NSHost
NSISEngine
NSISLinearExpression
NSISObjectiveLinearExpression
NSISPlaybackOperation
NSISVariable
NSIncrementalStoreNode
NSIndexPath
NSIndexSet
NSInsertionPointHelper
NSInvocation
NSItemProvider
NSJSONSerialization
NSJoin
NSKeyValueAccessor
NSKeyValueContainerClass
NSKeyValueMutatingCollectionMethodSet
NSKeyValueNonmutatingCollectionMethodSet
NSKeyValueObservationInfo
NSKeyValueProperty
NSKeyValueProxyShareKey
NSKeyValueShareableObservationInfoKey
NSKnownKeysMappingStrategy
NSLayoutConstraint
NSLayoutConstraintParser
NSLayoutManager
NSLayoutManagerTextBlockHelper
NSLayoutManagerTextBlockRowArrayCache
NSLineFragmentRenderingContext
NSLinguisticTagger
NSLocale
NSLock
NSManagedObject
NSManagedObjectContext
NSManagedObjectID
NSManagedObjectModel
NSManagedObjectModelBundle
NSMapTable
NSMappingModel
NSMergeConflict
NSMergePolicy
NSMetadataItem
NSMetadataQuery
NSMetadataQueryAttributeValueTuple
NSMetadataQueryResultGroup
NSMethodSignature
NSMigrationContext
NSMigrationManager
NSMultiReadUniWriteLock
NSNetService
NSNetServiceBrowser
NSNetServicesInternal
NSNotification
NSNotificationCenter
NSNotificationQueue
NSNull
NSOperation
NSOperationQueue
NSOrderedSet
NSOrthography
NSParagraphStyle
NSParagraphStyleExtraData
NSPersistentStore
NSPersistentStoreCache
NSPersistentStoreCoordinator
NSPersistentStoreMap
NSPersistentStoreRequest
NSPersistentStoreResult
NSPipe
NSPointerArray
NSPointerFunctions
NSPort
NSPortMessage
NSPortNameServer
NSPredicate
NSPredicateOperator
NSPrivateCoreDataClassForFindingBundle
NSProcessInfo
NSProgress
NSProgressValues
NSPropertyDescription
NSPropertyListSerialization
NSPropertyMapping
NSPropertyTransform
NSRLEArray
NSRTFReader
NSRTFReaderTableState
NSRTFWriter
NSRecursiveLock
NSRegularExpression
NSRubyAnnotation
NSRunLoop
NSRunStorage
NSSQLAdapter
NSSQLAliasGenerator
NSSQLBindIntarray
NSSQLBindVariable
NSSQLChannel
NSSQLConnection
NSSQLCorrelation
NSSQLCorrelationTableUpdateTracker
NSSQLGenerator
NSSQLIntermediate
NSSQLPredicateAnalyser
NSSQLStatement
NSSQLStoreMappingGenerator
NSSQLiteIntarrayTable
NSScanner
NSSet
NSShadow
NSSharedKeySet
NSSortDescriptor
NSStorage
NSStoreMapNode
NSStoreMapping
NSStoreMappingGenerator
NSStoreMigrationPolicy
NSStream
NSString
NSStringDrawingContext
NSStringDrawingTextStorageSettings
NSString_stripHtml_XMLParsee
NSSubstituteWebResource
NSTaggedPointerString
NSTaggedPointerStringCStringContainer
NSTask
NSTextAlternatives
NSTextAttachment
NSTextBlock
NSTextBlockLayoutHelper
NSTextCheckingResult
NSTextContainer
NSTextList
NSTextTab
NSThread
NSTimeZone
NSTimer
NSTypesetter
NSURL
NSURLAuthenticationChallenge
NSURLAuthenticationChallengeInternal
NSURLCache
NSURLCacheInternal
NSURLComponents
NSURLConnection
NSURLConnectionInternal
NSURLCredential
NSURLCredentialStorage
NSURLDownload
NSURLDownloadInternal
NSURLFileTypeMappings
NSURLFileTypeMappingsInternal
NSURLHostNameAddressInfo
NSURLKeyValuePair
NSURLProtectionSpace
NSURLProtocol
NSURLProtocolInternal
NSURLQueryItem
NSURLQueue
NSURLQueueNode
NSURLRequest
NSURLRequestInternal
NSURLResponse
NSURLResponseInternal
NSURLSession
NSURLSessionConfiguration
NSURLSessionTask
NSURLStorage_CacheClient
NSUUID
NSUbiquitousKeyValueStore
NSUndoManager
NSUndoTextOperation
NSUserActivity
NSUserDefaults
NSValidationErrorLocalizationPolicy
NSValue
NSValueTransformer
NSWeakCallback
NSXMLParser
NSXPCConnection
NSXPCInterface
NSXPCListener
NSXPCListenerEndpoint
Phrase
Protocol
RadiosPreferences
Random_ProtocolMethodContainer
RectLike_ProtocolMethodContainer
RunLoopController
SBAppLaunchUtilities
SBLaunchAppListener
SBSAccelerometer
SBSAssertion
SBSCardItem
SBSCardItemsController
SBSLocalNotificationClient
SBSLockScreenPluginService
SBSRemoteNotificationClient
SBSStatusBarStyleOverridesAssertion
SBSStatusBarStyleOverridesAssertionData
SBSStatusBarStyleOverridesAssertionManager
SelectorMatcher
SpeechSynthesizerDelegate
SpeexEndpointer
THBinder
THObserver
TypedArray_ProtocolMethodContainer
UIAcceleration
UIAccelerometer
UIAccessibilityCustomAction
UIAccessibilityElement
UIActivity
UIActivityItemImageRep
UIActivityItemURLRep
UIAlertAction
UIAlertControllerDescriptor
UIAlertControllerStackManager
UIAlertControllerVisualStyle
UIAnimation
UIAnimator
UIAutoscroll
UIBarButtonItemProxy
UIBarItem
UIBezierPath
UIButtonContent
UICellHighlightingSupport
UIClassSwapper
UIClassicController
UIClientRotationContext
UICollectionViewAnimation
UICollectionViewData
UICollectionViewLayout
UICollectionViewLayoutAttributes
UICollectionViewLayoutInvalidationContext
UICollectionViewUpdate
UICollectionViewUpdateGap
UICollectionViewUpdateItem
UIColor
UICompletionTablePrivate
UICompositeImageElement
UIControlTargetAction
UICustomObject
UIDOMHTMLOptGroupSelectedItem
UIDOMHTMLOptionSelectedItem
UIDelayedAction
UIDevice
UIDeviceAppearanceContainer
UIDictationController
UIDictationLandingViewSettings
UIDictationPhrase
UIDictationStreamingOperations
UIDocument
UIDocumentAlertPresenter
UIDocumentErrorRecoveryAttempter
UIDocumentInteractionController
UIDocumentStorageManager
UIDragger
UIDynamicAnimator
UIDynamicAnimatorTicker
UIDynamicBehavior
UIEvent
UIFlicker
UIFloatArray
UIFont
UIFontDescriptor
UIGestureDelayedTouch
UIGestureInfo
UIGestureRecognizer
UIGestureRecognizerTarget
UIGradient
UIImage
UIImageAsset
UIInputSwitcher
UIInputViewAnimationControllerBasic
UIInputViewAnimationControllerSlide
UIInputViewAnimationControllerSlideContext
UIInputViewAnimationControllerViewController
UIInputViewAnimationControllerViewControllerContext
UIInputViewAnimationStyle
UIInputViewAnimationStyleExtraView
UIInputViewPlacementTransition
UIInputViewPostPinningReloadState
UIInputViewSet
UIInputViewSetNotificationInfo
UIInputViewSetPlacement
UIInputViewTransition
UIKBCacheToken
UIKBEdgeEffect
UIKBGeometry
UIKBGradient
UIKBGraphCache
UIKBHandwritingPointFIFO
UIKBKeyDisplayContents
UIKBKeyInterval
UIKBMergeAction
UIKBRenderConfig
UIKBRenderFactory
UIKBRenderFactoryLayoutSegment
UIKBRenderGeometry
UIKBRenderTraits
UIKBRenderer
UIKBScreenTraits
UIKBShadowEffect
UIKBShape
UIKBShapeOperator
UIKBSplitKeyplaneGenerator
UIKBSplitRow
UIKBSplitTraits
UIKBTextEditingTraits
UIKBTextStyle
UIKBTree
UIKeyCommand
UIKeyboardAutocorrectionController
UIKeyboardCache
UIKeyboardCandidateUtilities
UIKeyboardEmoji
UIKeyboardEmojiCategory
UIKeyboardEmojiCategoryController
UIKeyboardEmojiDefaultsController
UIKeyboardEmojiGraphics
UIKeyboardEmojiInputController
UIKeyboardInputManagerClient
UIKeyboardInputManagerClientRequest
UIKeyboardInputManagerMux
UIKeyboardInputModeController
UIKeyboardKeyplaneTransition
UIKeyboardPreferencesController
UIKeyboardRotationState
UIKeyboardScheduledTask
UIKeyboardSliceSet
UIKeyboardSliceStore
UIKeyboardSyntheticTouch
UIKeyboardTaskExecutionContext
UIKeyboardTaskQueue
UIKeyboardTouchInfo
UIKeyboardTransitionSlice
UIKit_PKSubsystem
UILexicon
UILexiconEntry
UILocalNotification
UILocalizedIndexedCollation
UIMenuController
UIMenuItem
UIMorphingLabelGlyphSet
UIMotionEffect
UINavigationItem
UINib
UINibCoderValue
UINibKeyValuePair
UINibStorage
UINibStringIDTable
UIPanGestureVelocitySample
UIPasteboard
UIPercentDrivenInteractiveTransition
UIPeripheralHost
UIPeripheralHostState
UIPopoverController
UIPresentationController
UIPrintFormatter
UIPrintInfo
UIPrintInfoRequest
UIPrintInteractionController
UIPrintInteractionControllerInternals
UIPrintPageRenderer
UIPrintPanelViewController
UIPrintPaper
UIPrinter
UIPrinterInternals
UIPrinterPickerController
UIPrinterPickerControllerInternals
UIPrintingProgress
UIProxyObject
UIRemoteApplication
UIRemoteSheetInfo
UIResponder
UIRivenFactory
UIRuntimeAccessibilityConfiguration
UIRuntimeConnection
UIScreen
UIScreenMode
UIScrollTestParameters
UISearchDisplayController
UISectionRowData
UISliderContent
UIStatusBarAnimationParameters
UIStatusBarComposedData
UIStatusBarForegroundStyleAttributes
UIStatusBarItem
UIStatusBarLayoutManager
UIStatusBarPublisher
UIStatusBarServer
UIStatusBarStyleAttributes
UIStatusBarStyleRequest
UIStoryboard
UIStoryboardScene
UIStoryboardSegue
UIStoryboardSegueTemplate
UISubTest
UITabBarItemProxy
UITableViewCellEditingData
UITableViewCellLayoutManager
UITableViewCellUnhighlightedState
UITableViewControllerKeyboardSupport
UITableViewDataSource
UITableViewRow
UITableViewRowAction
UITableViewRowData
UITableViewSection
UITableViewUpdateGap
UITapRecognizer
UITextChecker
UITextCheckerDictionaryEntry
UITextInputArrowKeyHistory
UITextInputController
UITextInputMode
UITextInputStringTokenizer
UITextInputTraits
UITextInteractionAssistant
UITextMagnifierTimeWeightedPoint
UITextPosition
UITextRange
UITextRenderingAttributes
UITextReplacement
UITextReplacementGenerator
UITextSelection
UITextSelectionRect
UIThreadSafeNode
UITouch
UITouchData
UITouchTapInfo
UITraitCollection
UITwoSidedAlertController
UIUpdateItem
UIUserNotificationAction
UIUserNotificationActionSettings
UIUserNotificationCategory
UIUserNotificationSettings
UIViewAnimation
UIViewAnimationBlockDelegate
UIViewAnimationContext
UIViewAnimationState
UIViewControllerAction
UIViewControllerBuiltinTransitionViewAnimator
UIViewHeartbeat
UIVisualEffect
UIWKAutocorrectionContext
UIWKAutocorrectionRects
UIWebBrowserFindOnPageHighlighter
UIWebClip
UIWebClipIcon
UIWebClipLinkTag
UIWebDefaultDateTimePicker
UIWebElementAction
UIWebElementActionInfo
UIWebFormDateTimePeripheral
UIWebFormDelegate
UIWebFormSelectPeripheral
UIWebGeolocationPolicyDecider
UIWebOptGroup
UIWebOverflowScrollInfo
UIWebOverflowScrollListener
UIWebOverflowScrollViewInfo
UIWebPDFLinkAction
UIWebPDFSearchController
UIWebPDFSearchResult
UIWebPDFViewHandler
UIWebPaginationInfo
UIWebRotatingNodePopover
UIWebSelection
UIWebSelectionAssistant
UIWebSelectionGraph
UIWebSelectionNode
UIWebURLAction
UIWebViewInternal
UIWebViewWebViewDelegate
UIWindowController



/*
  for(id x in @[ $(@"%s/%@.h", BUILT_PRODUCTS_DIR, projNme),
                 $(@"%@/%@.h", srcroot,            projNme)])

int _longest(id strings);


int _longest(id strings) {
    return (int)

        [[[strings sortedArrayUsingDescriptors:
                       @[ [NSSortDescriptor.alloc initWithKey:@"length" ascending:YES selector:@selector(localizedStandardCompare:)] ]] firstObject] length];
}


@interface      HeaderWriter : NSObject @end
@implementation HeaderWriter { NSMutableString* _outString; id _plist; }

- initWithPlist:path { return self = super.init &&

  [NSFileManager.defaultManager fileExistsAtPath:_plist = list isDirectory:NULL] ? self : nil;
}
- (NSMutableString*) outString { return _outString = _outString ?: [NSMutableString plist2Header:_plist]; }
@end

//// The NSRegularExpression class is currently only available in the Foundation framework of iOS 4
//NSError *error = NULL;
//NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"@property\\s*?\\(nonatomic\\,\\s*?readonly\\)\\s*" options:NSRegularExpressionAnchorsMatchLines error:&error];
//NSString *result = [regex stringByReplacingMatchesInString:searchText options:0 range:NSMakeRange(0, [searchText length]) withTemplate:@"_RO "];

//        __block NSString *newType = nil;
//
//            [def enumerateSubstringsInRange:NSMakeRange(0, def.length)
//                                    options:NSStringEnumerationByWords|NSStringEnumerationReverse
//                                 usingBlock:^(NSString*subs, NSRange sbr, NSRange enclR, BOOL *s) {
//                newType = subs; *stop = YES;
//            }];

//          NSUInteger space = [def rangeOfString:@" "].location;
//          NSString *newType = [def substringFromIndex:space],
            // stringByReplacingOccurrencesOfString:newType withString:@""];
           // substringToIndex:[def rangeOfString:newType].location];


@interface      Replacement : NSObject  @property NSMutableArray *matches; @end

@implementation Replacement

- initWithString:(NSString*)d { if (!(self = super.init)) return nil;

//    [entry enumerateKeysAndObjectsUsingBlock:^(NSString* kind, id definitions, BOOL *s) {
//
//        [kind hasPrefix:@"define"] ?
//
//        [header if:kind do:^{ for (id def in definitions) [header addDefine:def]; }] :
//
//        [kind isEqualToString:@"map"]    ? [header appendMap:definitions] : nil;
//    }];
//
//  entries = e; type = t;  platform = p;
  return self;
}
- (NSMutableString*) generated { NSMutableString *outString = @"\n".mutableCopy;

 return outString;
//  Validity == Universal ?
//  if (type)
}
@end

- (void) _addDefines:pair { // dstr = [dstr hasPrefix:@" "] ? dstr[-1] : dstr;

    NSUInteger space = LOC(dstr,@" "); // defines are split at first "space".

    [self appendFormat:@"#define %30s %@\n", [pair[0] UTF8String], pair[1]];
}

void _preProc() {

  NSLog(@"pointers: %@, primitives: %@, classshortcuts: %@, paranthized: %@", pointers, primitives, classShortcuts, parenthized);

//  static Rx *shortcuts = nil;
//  shortcuts = shortcuts ?: RX([classShortcuts.allKeys componentsJoinedByString:@"|"]);

  for (id arg in args) ![arg isMatch:RX(@".*\\.(m|h)$")] ?: ({  NSLog(@"Need to preprocess %@", arg);

    __unused M(String) *work = [M(String) stringWithContentsOfFile:arg encoding:NSUTF8StringEncoding error:nil];

  });

}


@implementation M(String) (Plist2Header)

- (void) _if:key do:(void (^)())stuff {

    NSString* exclusive = LOC(key,@"_") == NSNotFound ? nil : key[ - (LOC(key,@"_") + 1) ];

    exclusive ? $APPEND(self, @"\n#if %@ // $@\n\n", exclusive) : CR(self); stuff();
    exclusive ? $APPEND(self, @"\n#endif // %@\n",   exclusive) : CR(self);
}

- (void) _appendMap:dict { M(String)* methArgs, *dereferenceable;

    [dict enumerateKeysAndObjectsUsingBlock:^(id mapping, id map, BOOL* stop) {

      [self _if:mapping do:^{

        $APPEND(self,@"#pragma mark - %@ \n\n", mapping);

        [self appendString:CUTE_HEADER(@"VAGEEN")];
        
        for (NSString * standard in [map keysSortedByValueUsingSelector:@selector(compare:)]) {

          NSString *newType = map[standard];
          BOOL    isPointer = LOC(standard,@"*") != NSNotFound;

          $APPEND(self,@"_Type %30s  %@ _\n", standard.UTF8String, newType);

          if (isPointer && [@[@"CA", @"NS", @"AV"] containsObject:[standard substringToIndex:2]]) { // dereferenceable

            NSString *prefix = [newType substringToIndex:1],
                  * originalClassName = standard[standard.length -2],
                  * shortcut = [newType[-1] stringByAppendingString: ![prefix isEqualToString:@"_"]
                                                                     ? prefix.uppercaseString : @""];

            $APPEND(dereferenceable, @"\n#define %30s  %@", shortcut.UTF8String, originalClassName);
            (classShortcuts = classShortcuts ?:@{}.mutableCopy)[originalClassName] = shortcut;
          }

          // Add parenthised to dict for regex.
          (parenthized = parenthized ?: @{}.mutableCopy)[$(@"(%@)", newType)] = $(@"%@_", newType);

          $APPEND(methArgs,@"\n#define %15s_  (%@)", newType.UTF8String, newType); // add panethised to header in methargs block
        }
      }];

    }];

    $APPEND(self,@"%@\n\n%@", _uSort(methArgs),_uSort(dereferenceable));
}
typedef NS_ENUM(int,Emits) { EmitsDefines, EmitsTypes  };
typedef NS_ENUM(int,SortBy){ SortByLength, SortByAlpha };

@end
//      ?: @[ $(@"%s/%@.h", BUILT_PRODUCTS_DIR, projNme()), $(@"%@/%@.h", srcroot(),projNme())];

*/




#defaults write "$PROJ_DOMAIN_" hash "$NEW_HASH_" 2> /dev/null
#     NEW_HASH_="$(md5 -q $INSTALLABLE_)"
#     OLD_HASH_="$(defaults read $PROJ_DOMAIN_ hash 2> /dev/null)"
#
# setDefaults () { defaults write "$PROJ_DOMAIN_" hash "$NEW_HASH_"; defaults write "$PROJ_DOMAIN_" xcode "$XCODE_NOW_" }
#
#echo "pref_key:$PROJ_DOMAIN_\nold hash: $OLD_HASH_\nnew_hash: $NEW_HASH_\n  xc_def: $XCODE_WAS_\n  xc_now: $XCODE_NOW_"
#
#[[ "$OLD_HASH_" == "$NEW_HASH_" ]] && echo "hashes are same. aborting. OK!" # && exit 0

#DRVD_DATA_="$(defaults read com.apple.dt.Xcode IDECustomDerivedDataLocation)"
#MOD_CACHE_="$DRVD_DATA_/ModuleCache"
#
#[[ -d "$MOD_CACHE_" ]] && rm -r "$MOD_CACHE_" && echo "\033[48;5;$CmCleared cache at $MOD_CACHE_!" || echo "Could clear cache"

# open --reveal "$DDATA"

#[[ ( $# ) ]] && say $# || {
#
#  putf "running optional"
#  DDATA="$(defaults read com.apple.dt.Xcode IDECustomDerivedDataLocation)"
#
#}
#/*/../bin/ls > /dev/null
#
#NEED_REBUILD=                                        # delete module cache?
#INSTALL_FILE="$(pwd)/$0"                             # THIS
#
#for x in 'iphonesimulator' 'iphoneos' 'macosx'; { ((C++))
#
#  SDKPATH="$(xcrun --show-sdk-path -sdk $x --no-cache 2> /dev/null)/usr/include"
#  DESTLOC="$SDKPATH/$(basename $0)"
#  [[ -z "$SDKPATH" ]] && exit 99
#  [[ -a "$DESTLOC" ]] && ! diff "$INSTALL" "$DESTLOC" && say "Skipping $x" && continue
#  [[ -a "$DESTLOC" ]] && rm "$DESTLOC"
#  cp "$INSTALL" "$SDKPATH" && REBUILD=1
#  echo "\033[38;5;$C;5mInstalled $(basename $0) into ${SDKPATH##*SDKs} folder.\033m"
#}
#
#[[ $REBUILD ]] && echo rebuilding || echo NOT rebuilding
#
#exit
#
#*/
# :-$(md5 -q "$PROJ_HEADER")}


//  NSLog(@"argc is now:%i, argv is now %p: template is: %@ data is %@", argc, argv, templatePath, dataPath);

//
//  for (int i = )
//
//    NSString *outF = [FM stringWithFileSystemRepresentation:argv[1] length:strlen(argv[1])];
//    if (outF) outPaths = [outPaths?:@[] arrayByAddingObject:outF];
//    ar
//  }

//        {
//            NSString *inputFile = [NSString stringWithFileSystemRepresentation:argv[0]];
//            NSString *outputFile = [NSString stringWithFileSystemRepresentation:argv[1]];
//            
//            CDFile *file = [CDFile fileWithContentsOfFile:inputFile searchPathState:nil];
//            if (file == nil) {
//                fprintf(stderr, "Error: input file is neither a Mach-O file nor a fat archive.\n");
//                exit(EX_DATAERR);
//            }
//            
//            CDMachOFile *thinFile = nil;
//            if ([file isKindOfClass:[CDMachOFile class]]) {
//                thinFile = (CDMachOFile *)file;
//            } else if ([file isKindOfClass:[CDFatFile class]]) {
//                if (targetArch.cputype == CPU_TYPE_ANY) {
//                    if ([file bestMatchForLocalArch:&targetArch] == NO) {
//                        fprintf(stderr, "Internal Error: Couldn't get local architecture.\n");
//                        exit(EX_SOFTWARE);
//                    }
//                }
//                thinFile = [(CDFatFile *)file machOFileWithArch:targetArch];
//                if (!thinFile) {
//                    const NXArchInfo *arhcInfo = NXGetArchInfoFromCpuType(targetArch.cputype, targetArch.cpusubtype);
//                    fprintf(stderr, "Error: input file does not contain the '%s' arch.\n", arhcInfo->name);
//                    exit(EX_DATAERR);
//                }
//            } else {
//                fprintf(stderr, "Internal Error: file is neither a CDFatFile nor a CDMachOFile instance.\n");
//                exit(EX_SOFTWARE);
//            }
//            
//            BOOL hasProtectedSegments = saveDeprotectedFileToPath(thinFile, outputFile);
//            if (!hasProtectedSegments) {
//                const NXArchInfo *arhcInfo = NXGetArchInfoFromCpuType(targetArch.cputype, targetArch.cpusubtype);
//                fprintf(stderr, "Error: input file (%s arch) is not protected.\n", arhcInfo->name);
//                exit(EX_DATAERR);
//            }
//        }


//  if (argc < 3) print_usage(), exit(EXIT_FAILURE);


/*
//  NSLog(@"got plist: %@\n header:%@\n out:%@", model, templ, output ?: @"stdout");
//    NSLog(@"simulating writing to path: %@", path);

NSString * srcroot (){

  return [NSString stringWithUTF8String:__FILE__].stringByDeletingLastPathComponent;
}

      id  listPath (){

  return  args.count > 1 ? args[1] : $(@"%@/%@.plist", srcroot(), srcroot().lastPathComponent);
}

      id template (){ return $(@"%@/%@_Template.h", srcroot(), srcroot().lastPathComponent); }

struct io_opts { // name of long option
	const char *name;
	// one of no_argument, required_argument, and optional_argument: whether option takes an argument
	int has_arg;
	// if not NULL, set *flag to val when option found
	int *flag;
	// if flag not NULL, value to set *flag to; else return value
	int val;
};

  int ch;

  static struct option longopts[] = { { "template",    required_argument, NULL, 't' },
                                      { "definitions", required_argument, NULL, 'd' }, {NULL, 0, NULL, 0 }};

  while ((ch = getopt_long(argc, argv, "t:d:", longopts, NULL)) != -1)

    error = ch == 't' ? (templatePath = _validatePath(optarg)) ? nil : @"need a valid template file"  :
            ch == 'd' ? (    dataPath = _validatePath(optarg)) ? nil : @"ned a valid plist path"
                      : @"something went wrong";

  argc -= optind;
  argv += optind;

  // Print any remaining command line arguments (not options).
  if (optind < argc) while (optind < argc) {

      const char *extra = argv[optind++];
      NSString *outF = [FM stringWithFileSystemRepresentation:extra length:strlen(extra)];
      if (outF) outPaths = [outPaths?:@[] arrayByAddingObject:outF];
    }

  if (error || argc < 2) print_usage(error), exit(EXIT_SUCCESS);
  
  void print_usage(id error) {

  fprintf(stderr,"\nUsage: %s -t <templatefile> -d <dataPlistFile> <outputPath> [otherOutputPaths]\n\n"
    " -t, --template      <file>  POOPIE the protoype template file's path\n"
    " -d, --definisitions <file>  the plist data file's path\n\n"
    "What we have:\n"
    "  Template: %s\n      Data: %s\n  Outfiles: %lu%s%s\n",
    NSProcessInfo.processInfo.processName.UTF8String,
    templatePath.UTF8String, dataPath.UTF8String, outPaths.count,
    error ? "\n\nError: " : "", error ? [error UTF8String] : "");
}
//    NSLog(@"current arg:%@ isFlag:%@ idx:%lu", arg, argIsFlag ? @"YES" : @"NO", i);

*/




#ifndef _ObjC__ObjC_pch
#define _ObjC__ObjC_pch


#endif

/*
NS_INLINE id _sTask(id cmd) { return !cmd ? nil : ({ NSPipe* pipe; NSTask * task;

  [task = NSTask.new setValuesForKeysWithDictionary: @{  @"launchPath" : @"/bin/sh",
                                                          @"arguments" : @[@"-c", cmd],
                                                     @"standardOutput" : pipe = NSPipe.pipe}]; [task launch];
  [NSString.alloc initWithData: pipe.fileHandleForReading.readDataToEndOfFile encoding:NSUTF8StringEncoding]; });
}

NS_INLINE id _uSort(id str) { return _sTask($(@"echo \"%@\"|sort|uniq", str)); }


NS_INLINE NSString * CUTE_HEADER(id str) { M(String)*line = @"".mutableCopy;

/// HELPERS
//////////////

  for (int i = 0; i < [str length] + 6; i++) [line appendString:@"/"];
  return $(@"%@\n// %@ //\n%@\n", line, str, line);
}

*/

/// #define XcodePath _system(@"printf \"${$(xcode-select -p)%.app/*}.app\"")



env | sort | grep -i BUIL

    TOOL="${BUILT_PRODUCTS_DIR}/${PROJECT_NAME}_Tool"
   PLIST="$SCRIPT_INPUT_FILE_0"
TEMPLATE="$SCRIPT_INPUT_FILE_1"
     OUT=( "$SCRIPT_OUTPUT_FILE_0" )

"$TOOL" -t "$TEMPLATE" -plist "$PLIST" -o ${OUT[@]}

# ln -sF "$SCRIPT_OUTPUT_FILE_0" "$SCRIPT_OUTPUT_FILE_1"
# $(SRCROOT)/$(PROJECT_NAME).h