Overview
========

DatabaseStorage is a simple and reusable Obj-C class that provides a key-value store based on SQLite3. It comes with a basic command line tool for testing.

License
=======

DatabaseStorage is available under [New BSD License](LICENSE).
