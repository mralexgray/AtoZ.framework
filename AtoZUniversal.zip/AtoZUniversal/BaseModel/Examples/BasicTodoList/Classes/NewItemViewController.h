//
//  NewItemViewController.h
//  TodoList4
//
//  Created by Nick Lockwood on 15/04/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TodoItem;

@interface NewItemViewController : UIViewController <UITextViewDelegate>

@end
