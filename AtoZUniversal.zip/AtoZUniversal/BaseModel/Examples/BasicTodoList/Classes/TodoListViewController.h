//
//  TodoListViewController.h
//  TodoList
//
//  Created by Nick Lockwood on 08/04/2010.
//  Copyright Charcoal Design 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TodoListViewController : UITableViewController

- (IBAction)createNewItem;

@end

