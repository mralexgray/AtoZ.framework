//
//  main.m
//  MacHRAutoTodoList
//
//  Created by Alex Gray on 11/26/12.
//  Copyright (c) 2012 Alex Gray. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}
