/* Copyright (c) 2011, Nate Stedman <natesm@gmail.com>
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.	*/

#import "NSGradient+FunSize.h"

#if !TARGET_OS_IPHONE
#import "NSColor+FunSize.h"

@implementation NSGradient (FunSize)

+(NSGradient*)gradientFrom:(NSColor*)start to:(NSColor*)end	{
    return [self.alloc initWithStartingColor:start endingColor:end];
}

+(NSGradient*)gradientFromHex:(NSString*)start to:(NSString*)end
{
    return [self.alloc initWithStartingColor:[NSColor colorWithHex:start]
                                    endingColor:[NSColor colorWithHex:end]];
}

-(id)initWithStartingHex:(NSString*)start endingHex:(NSString*)end
{
    return self = [self initWithStartingColor:[NSColor colorWithHex:start] endingColor:[NSColor colorWithHex:end]];
}

+(NSGradient*)gradientFromHex:(NSString*)start alpha:(CGFloat)startAlpha to:(NSString*)end alpha:(CGFloat)endAlpha;
{
    return [self.alloc initWithStartingHex:start alpha:startAlpha endingHex:end alpha:endAlpha];
}

-(id)initWithStartingHex:(NSString*)start alpha:(CGFloat)startAlpha endingHex:(NSString*)end alpha:(CGFloat)endAlpha
{
    return self = [self initWithStartingColor:[[NSColor colorWithHex:start] colorWithAlphaComponent:startAlpha]
                                  endingColor:[[NSColor colorWithHex:end] colorWithAlphaComponent:endAlpha]];
}

@end
#endif