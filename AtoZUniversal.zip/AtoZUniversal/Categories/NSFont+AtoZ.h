

@Xtra(NSFont, AtoZ)

_RO _Flot size, fixed_xHeight, fixed_capHeight;

#if MAC_ONLY
- _Font_ fontWithSize:_Flot_ z;
#endif
@end

