//
//  SplitEnumClient.h
//  JREnumTest
//
//  Created by Wolf Rentzsch on 12/10/12.
//  Copyright (c) 2012 Jonathan 'Wolf' Rentzsch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SplitEnumClient : NSObject

@end
