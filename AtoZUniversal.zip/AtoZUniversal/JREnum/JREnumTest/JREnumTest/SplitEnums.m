#import "SplitEnums.h"

JREnumDefine(SplitEnumWith1ConstantSansExplicitValues);

JREnumDefine(SplitEnumWith1ConstantWithExplicitValues);

JREnumDefine(TestClassState);
